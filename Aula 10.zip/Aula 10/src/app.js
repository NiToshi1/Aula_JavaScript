// Importar Express
const express = require("express");
// Instanciando o Express
const app = express();
const port = 3000;

// Configurando nosso Middlewares
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Configurando o EJS
app.set("view engine", "ejs");
// Configuração opcional
app.set("views", "./src/views");

// Renderizando a página HTML/EJS diretamente
app.get("/", (req, res) => {
    const NOMESISTEMA = "SysHelton";
    res.render('index', {nome: NOMESISTEMA});
});

app.get('/carros', (req, res) => {
    let cars = [
        {id: 1, marca: 'GM', modelo: 'Corsa'},
        {id: 2, marca: 'VW', modelo: 'Gol'},
        {id: 3, marca: 'Toyota', modelo: 'Corolla'},
        {id: 4, marca: 'VW', modelo: 'Limão8'},
        {id: 5, marca: 'Renault', modelo: 'Duster'},
        {id: 6, marca: 'Ferrari', modelo: '712'}
    ]

    res.render('list_carros', {listaCarros: cars});
});

app.get('/motos', (req, res) => {
    const MOTOS = [
        {id: 1, marca: 'Honda', modelo: 'Start 160'},
        {id: 2, marca: 'Honda', modelo: 'Titan 160'},
        {id: 3, marca: 'Honda', modelo: 'Biz 1000'},
        {id: 4, marca: 'Honda', modelo: 'z900'}
    ]
    res.render('list_motos', {LISTA_DE_MOTOS: MOTOS})
});

// Iniciando o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});